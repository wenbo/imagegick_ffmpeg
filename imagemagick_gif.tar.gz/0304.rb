system("convert -size 168x400 xc:'#f396eb' `date +%m%d`.gif")
dir_path = Dir.pwd
titles = ["title1", "title2", "title3", "title4", "title5", "titile6"]
system("convert `date +%m%d`.gif 0.jpg -geometry +25+55 -composite 0.png")
system("convert `date +%m%d`.gif 1.jpg -geometry +45+255 -composite 1.png")
system("convert `date +%m%d`.gif 2.jpg -geometry +55+355 -composite 2.png")
system("convert `date +%m%d`.gif 3.jpg -geometry +15+155 -composite 3.png")
system("convert `date +%m%d`.gif 4.jpg -geometry +45+55 -composite 4.png")
system("convert -delay 50 *.png `date +%m%d%H`.gif")
